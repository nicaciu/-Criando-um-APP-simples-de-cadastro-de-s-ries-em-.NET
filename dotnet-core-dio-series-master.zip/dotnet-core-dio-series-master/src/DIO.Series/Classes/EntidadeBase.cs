namespace src.DIO.Series.Classes
{
    public abstract class EntidadeBase
    {
        public int Id { get; protected set; }
    }
}
